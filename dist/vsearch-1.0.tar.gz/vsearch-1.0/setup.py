from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    author='Aarga Samuel',
    author_email='sam.sonter@hotmail.com',
    py_modules=['vsearch'],
)
